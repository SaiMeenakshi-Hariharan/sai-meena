import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private authService: AuthService, private router: Router, private cookieService: CookieService) { }

  ngOnInit(): void {
  }

  data: any = { };
  formSubmit(){
    this.authService.login(this.data).subscribe(
      res => {
        this.cookieService.set( 'access_token', res.token );
        this.router.navigate(['layout1/dashboard']);
      });
  }

}
