import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from '../dashboard/dashboard.component'
import { UsersComponent } from '../users/users.component';
import { RouterModule } from '@angular/router';

const router = [
  {path: '', component: DashboardComponent},
  {path: 'users', component: UsersComponent} 
]

@NgModule({
  declarations: [
    DashboardComponent,
    UsersComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(router)
  ]
})
export class LayoutModule { }
